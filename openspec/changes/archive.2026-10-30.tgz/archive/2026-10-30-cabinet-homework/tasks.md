# Tasks

## 1. Модели и миграция

- [x] 1.1 `app/homework/models/answer.py` (`HomeworkAnswer`: homework_id UNIQUE
  FK CASCADE, text nullable, submitted_at) и `app/homework/models/answer_link.py`
  (`HomeworkAnswerLink`: answer_id FK CASCADE, url String(500), position),
  реэкспорт в `app/models.py` (D1). Проверка: `uv run python -c "import app.models"`.
- [x] 1.2 Миграция Alembic: `uv run alembic revision --autogenerate -m
  "homework answers"`, в файле — только две новые таблицы; `alembic upgrade head`,
  одна голова. Проверка: `uv run pytest -q` зелёный.

## 2. Сервисы ДЗ (`app/homework/services/`)

- [x] 2.1 `answer_form.py`: разбор формы (текст, список `links`), отбрасывание
  пустых строк, валидация (текст или ссылка; http(s); ≤500 символов) (D6).
  Проверка: тесты разбора — пустой ответ, кривая ссылка, только ссылки,
  только текст.
- [x] 2.2 `answer_writer.py`: `get_answer`, `save_answer` (создание/обновление
  ответа, замена ссылок через delete+insert, `flush` перед вставкой ссылок —
  `autoflush=False`, статус ДЗ → `submitted`) (D2). Проверка: тесты — первый
  ответ, повторная отправка (ссылки заменены, вторая запись не создана).

## 3. Сервисы кабинета (`app/cabinet/services/`)

- [x] 3.1 `homework.py`: список ДЗ ученика — два SELECT по образцу `lessons.py`,
  статус ≠ `not_assigned`, сортировка по дате урока по убыванию; ответы и
  ссылки — массовые SELECT `IN` + группировка, без N+1 (D3). Проверка: тесты —
  индивидуальное и групповое ДЗ, «Не задано» не показано, порядок.
- [x] 3.2 `access.py`: `get_student_homework(db, homework_id, student_id)` —
  владение через урок (individual XOR group member), иначе 404 (D7). Проверка:
  тесты — своё ДЗ находится, чужое/несуществующее — 404.
- [x] 3.3 `presentation.py`: «урок 30 октября 2026», «30 октября 2026, 12:00»,
  подпись статуса, класс чипа; регистрация в `app/templating.py`. Проверка:
  `uv run pytest -q` зелёный.

## 4. Вьюхи и шаблоны

- [x] 4.1 `app/cabinet/views/homework.py`: GET `/student/homework`
  (`require_student_id`) и POST `/student/homework/{homework_id}/answer`
  (HTMX-фрагмент карточки / 303 PRG, «Проверено» закрыто для отправки) (D5);
  роутер в `views/__init__.py`. Проверка: тесты — без сессии редирект, POST
  без JS — 303, чужое ДЗ — 404.
- [x] 4.2 Шаблоны `cabinet/homework.html` (страница со списком, пустое
  состояние) и `cabinet/_homework_card.html` (карточка `<details>`: чип, срок,
  задание, форма ответа с инлайн-Alpine «Добавить ссылку», режим «только
  чтение» после проверки); фрагмент рендерится с `open` после отправки (D4, D5).
- [x] 4.3 Сайдбар `cabinet/_sidebar.html`: «Домашние задания» — ссылка с
  активным состоянием, «Профиль» остаётся заглушкой. Проверка: тесты страницы.

## 5. Стили и иконки

- [x] 5.1 `styles.css`: классы `hw-card*`/`hw-answer*`/`hw-links*`, чипы
  `chip--hw-*`, только через токены темы. Проверка:
  `uv run pytest -q tests/test_css_styles.py`.
- [x] 5.2 Иконка `chevron-down`: `uv run python scripts/build_icons.py`.
  Каталог `cabinet` в `TEMPLATE_SETS` css-теста. Проверка:
  `uv run pytest -q tests/test_icons_bundle.py tests/test_css_styles.py`.

## 6. Тесты и документация

- [x] 6.1 `tests/test_cabinet_homework.py`: поведение через HTTP (список,
  раскрытие-разметка, отправка, валидация, повторная отправка, «Проверено»
  закрыто), изоляция по ученику (в т.ч. групповое ДЗ чужого ученика), 404,
  сессии. Проверка: `uv run pytest -q tests/test_cabinet_homework.py`.
- [x] 6.2 Полный прогон `uv run pytest -n auto`; README — раздел «Личный
  кабинет ученика» дополнен вкладкой. Проверка: тесты зелёные.

## Workflow follow-up

- После реализации: `opsx:archive` по завершении change'а.
- Следующий change (вне этого): просмотр ответов учеников в панели ДЗ
  репетитора (текст, ссылки, дата отправки); «Финансы» и «Профиль» кабинета.
