# Tasks

## 1. Сервис и эндпоинт

- [x] 1.1 `app/booking/services/booking_list.py` — `pending_count(db, tutor_id) -> int`:
      один `COUNT` с JOIN через `slots` и `status == "pending"`; проверка: тест на
      значение счётчика и пустое тело при нуле.
- [x] 1.2 `app/booking/views/count_partial.py` — `GET /tutor/bookings/count`:
      пустое тело при нуле, иначе число ожидающих; `require_tutor_id` — вход
      обязателен; регистрация в `app/booking/views/__init__.py` до
      параметрических маршрутов; проверка: тест эндпоинта (200, «2» / «»).

## 2. Сайдбар и стили

- [x] 2.1 `app/templates/sidebar.html` — в макрос `nav_link` необязательный
      `badge_url`: контейнер `span.nav-item__badge` с `id="nav-badge-{{ key }}"`,
      `hx-get`, `hx-trigger="load, every 30s, slot-saved from:body"`,
      `hx-swap="innerHTML"`; у пункта «Брони» —
      `badge_url="/tutor/bookings/count"`; проверка: тест — контейнер есть в
      разметке сайдбара с поллингом.
- [x] 2.3 Периодическое обновление: поллинг `every 30s` в том же триггере
      (новая заявка с публичной страницы не шлёт событий у педагога); проверка:
      тест — в `hx-trigger` контейнера есть `every 30s`.
- [x] 2.2 `app/static/styles.css` — `.nav-item__badge` на токенах
      `--destructive`/`--destructive-foreground` (кружок, `--text-xs`),
      `.nav-item__badge:empty { display: none }`, исключение для свёрнутого
      сайдбара (`html.sidebar-collapsed … .nav-item__badge:not(:empty)` → виден);
      проверка: `uv run pytest tests/test_css_styles.py tests/test_sidebar.py -q`.

## 3. Тесты и документация

- [x] 3.1 `tests/test_booking_page.py` — счётчик: число ожидающих, пусто при
      нуле, изоляция по репетитору, обновление после подтверждения/отклонения
      (партиал отдаёт уменьшенное число).
- [x] 3.2 `README.md` — в разделе «Возможности» упомянуть красный счётчик
      необработанных заявок на пункте «Брони» сайдбара.
- [x] 3.3 Полный прогон `uv run pytest -n auto` зелёный (1484 passed).
