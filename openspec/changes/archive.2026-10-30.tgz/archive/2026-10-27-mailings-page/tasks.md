# Tasks

## 1. Модели и миграция

- [x] 1.1 `app/messenger/models/sent_message.py`: `SentMessage` (tutor_id, student_id NULLABLE SET NULL, messenger CHECK, recipient, text, status CHECK `SENT_MESSAGE_STATUSES`, error, created_at); ре-экспорт в `messenger/models/__init__.py`, регистрация в `app/models.py`.
- [x] 1.2 `app/mailing/models/message_template.py`: `MessageTemplate` (tutor_id, title ≤ 200, text); регистрация в `app/models.py`.
- [x] 1.3 Миграция Alembic autogenerate (таблицы `message_templates`, `sent_messages`), `uv run alembic upgrade head`.

## 2. Журнал исходящих (messenger)

- [x] 2.1 `app/messenger/services/history.py`: `log_send` (строка после реальной попытки, атрибуция ученика по `(tutor_id, messenger, chat_id)`, без commit) и `list_messages` (чтение журнала с учеником).
- [x] 2.2 `app/messenger/services/send.py`: вызов `log_send` после попытки доставки (успех и `SendError`).

## 3. Сервисы mailing

- [x] 3.1 `services/access.py`: ри-экспорт доступа + `get_owned_template` (404).
- [x] 3.2 `services/recipients.py`: `list_recipients` (поиск + метрики + последний урок + каналы), сегменты `SEGMENTS`/`SEGMENT_LABELS`, `normalize_segment`.
- [x] 3.3 `services/rendering.py`: `PLACEHOLDERS`, `render_message` ({имя}, {баланс}, {следующий_урок}).
- [x] 3.4 `services/templates.py`: список/создание/правка/удаление, валидация (title, text непустые).
- [x] 3.5 `services/sender.py`: `send_mailing` (свои ученики, рендер, все подключённые каналы, сводка).
- [x] 3.6 `services/history.py`: `list_history` (последние 100, имя ученика, подписи).
- [x] 3.7 `services/presentation.py` + `services/page_context.py`: подписи (`recipients_count_label`, статус записи, метка мессенджера), контекст страницы.

## 4. Вьюхи и регистрация

- [x] 4.1 `views/index.py` (страница, `?tab=`), `views/tabs.py` (`/tabs/{tab}` + `HX-Push-Url`), `views/recipients.py` (партиал списка), `views/templates.py` (модалка списка, форма «новый», правка, удаление), `views/send.py` (POST, htmx — партиал композера, без JS — 303); сборка в `views/__init__.py`.
- [x] 4.2 Регистрация: `TEMPLATE_DIRS` + хелперы в `app/templating.py`, роутер в `main.py`.

## 5. Фронтенд

- [x] 5.1 Шаблоны `mailing/`: `index.html`, `_tabs.html`, `_content.html`, `_recipients.html`, `_composer.html`, `_templates_dialog.html`, `_template_form.html`, `_history.html`.
- [x] 5.2 `app/static/mailings.js`: фабрика `mailingsPage` (выбор, текст, шаблон, подстановка, сброс по событиям) и `mailingsTemplates` (диалог).
- [x] 5.3 CSS: классы `mailing-*` в `app/static/styles.css` (токены, без литералов).

## 6. Тесты и документация

- [x] 6.1 `tests/test_mailings.py`: доступ, вкладки, партиалы, сегменты/поиск, изоляция (список + 404 шаблонов + чужие id при отправке), шаблоны CRUD, отправка с подменой urlopen (подстановки, оба канала, пропуск без каналов, журнал sent/error), 303 без JS.
- [x] 6.2 README: раздел «Рассылки».
- [x] 6.3 `uv run pytest -n auto` зелёный.
