# Tasks

## 1. Модель и миграция

- [x] 1.1 В `app/tutor/models/tutor_settings.py` добавить константы дефолтов рабочего времени (`DEFAULT_WORKDAY_START = "06:00"`, `DEFAULT_WORKDAY_END = "23:00"`), колонки `workday_start`/`workday_end` (`String(5)`, NOT NULL, ORM-default) и ключи в `DEFAULTS`. Проверка: тест в `tests/test_profile.py` — `get_settings` без строки в БД возвращает «06:00»/«23:00».
- [x] 1.2 Миграция Alembic (autogenerate): две колонки с `server_default` «06:00»/«23:00» для существующих строк. Проверка: `uv run alembic upgrade head` на копии БД с данными — колонки заполнены, `uv run pytest -q tests/test_migration_utc.py` зелёный.

## 2. Форма вкладки «Календарь»

- [x] 2.1 В `app/tutor/services/calendar_form.py` добавить разбор рабочего времени: формат «ЧЧ:ММ», минуты 00, начало строго раньше окончания; ошибки вида «Рабочее время — …». Проверка: юнит-тест валидного интервала, кривого формата, минут ≠ 00 и обратного порядка — `uv run pytest -q tests/test_profile.py`.
- [x] 2.2 В `app/tutor/services/profile_page.py` дополнить `_form_defaults` вкладки calendar значениями из `get_settings` и передать в контекст список опций целых часов для селектов. Проверка: GET `/tutor/profile?tab=calendar` показывает блок «Рабочее время» с подставленными дефолтами (тест в `tests/test_profile.py`).
- [x] 2.3 В `app/tutor/templates/tutor/_tab_calendar.html` добавить карточку «Рабочее время» с двумя `<select>` (классы `field`/`label`/`input`), в `app/tutor/views/profile_calendar.py` — два `Form`-параметра и передача в `parse_calendar_form`. Проверка: POST сохраняет значения (redirect `saved=1`, повторный GET показывает их), POST с «18:00–09:00» даёт ошибку на вкладке; тест изоляции — настройки другого репетитора не меняются.
- [x] 2.4 Если в разметке появился новый BEM-класс — описать в `app/static/styles.css`. Проверка: `uv run pytest -q tests/test_css_styles.py` зелёный.

## 3. Сетка календаря по рабочему времени

- [x] 3.1 В `app/calendar/services/presentation.py` заменить константы `GRID_START_HOUR`/`GRID_END_HOUR`/`HOURS` расчётом из `grid_start_min`/`grid_end_min` (минуты суток, дефолт 360/1380): список строк таймлайна с готовыми подписями и четвертями (`< end`), `build_event_view` считает `top_h` от начала сетки и зажимает низ карточки концом сетки; строки и границы — в `build_calendar_context`. Проверка: юнит-тесты представления (09:00–18:00 → первая метка «09:00», конечная «18:00», четвертей после 18:00 нет; карточка 08:00–08:40 прижата к верху, 17:30–18:30 — к низу).
- [x] 3.2 В `app/calendar/views/index.py` прочитать `get_settings` и передать границы в `build_calendar_context`. Проверка: GET `/tutor/calendar` у репетитора с настройкой 09:00–18:00 рендерит сетку от 09:00 (тест в `tests/test_calendar.py`).
- [x] 3.3 В `app/calendar/templates/calendar/_area.html` строить колонку времени и `.cal-hour` дней из строк контекста (`grid_rows`), конечную метку — из границы, на корне сетки ставить `data-grid-start`/`data-grid-end`. Проверка: рендер без арифметики шаблона над `hours`; существующие тесты календаря (клики по четвертям, разметка `data-start`) зелёные.
- [x] 3.4 В `app/static/calendar.js` заменить `GRID_START_MIN`/`GRID_END_MIN` чтением `data-grid-start`/`data-grid-end` с fallback 360/1380: подсказка времени, зажим драга и зажим предзаполнения. Проверка: `node --check app/static/calendar.js`; сценарий спеки «Перетаскивание зажимается рабочим временем» — при 09:00–18:00 драг не уводит блок вне интервала (ручная проверка или тест логики clamp).
- [x] 3.5 Тесты в `tests/test_calendar.py`: дефолтная сетка 06:00–23:00 не изменилась; с настройкой 09:00–18:00 нет меток и четвертей вне интервала; уроки вне интервала видны, прижаты к границе и кликабельны (`hx-get` в разметке); `data-grid-start`/`data-grid-end` соответствуют настройке. Проверка: `uv run pytest -q tests/test_calendar.py`.

## 4. Интеграция и документация

- [x] 4.1 Обновить README.md: в разделе настроек репетитора указать рабочее время во вкладке «Календарь», в разделе «Расписание» — что сетка ограничена рабочим временем. Проверка: текст README согласован с поведением.
- [x] 4.2 Полный прогон: `uv run pytest -n auto` зелёный; `uv run openspec validate 2026-10-28-calendar-working-hours --strict` без ошибок.

## Workflow follow-up

- После ревью и применения — `/opsx:sync` для переноса дельт в основные спеки, затем `/opsx:archive`.
