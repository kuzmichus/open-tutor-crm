# Tasks

## 1. Сборщик набора

- [x] 1.1 `scripts/build_icons.py`: разбор экспортов бандла
      (`a.PascalName=переменная`)
- [x] 1.2 `scripts/build_icons.py`: `pascal_name` — алгоритм Lucide как есть
      (обратное преобразование Pascal → kebab неоднозначно: `Trash2` ≠ `trash2`)
- [x] 1.3 `scripts/build_icons.py`: `used_icon_names` — все строковые литералы
      `app/**/*.html|py|js`, отфильтрованные по существующим экспортам
- [x] 1.4 `scripts/build_icons.py`: `_extract_array` (балансировка скобок вне
      строк) и `_js_value_to_json` (ключи без кавычек → JSON)
- [x] 1.5 `scripts/build_icons.py`: рантайм `createIcons`/`render` — атрибуты по
      умолчанию, слияние с атрибутами `<i>`, `aria-hidden` только без
      `aria-*`/`role`/`title`, классы `lucide lucide-<имя>`, `data-lucide` на SVG
- [x] 1.6 Неизвестное имя → `SystemExit` со списком имён, а не молча пустая иконка

## 2. Перенос вендорного бандла

- [x] 2.1 `git mv app/static/lucide.min.js scripts/vendor/lucide.min.js`
- [x] 2.2 `app/templates/base.html`: `/static/icons.js` вместо `lucide.min.js`
- [x] 2.3 Сгенерировать `app/static/icons.js` (119 иконок, 23.6 КБ против 444 КБ)

## 3. Тесты

- [x] 3.1 `tests/test_icons_bundle.py`: каждая иконка-литерал есть в наборе
- [x] 3.2 `tests/test_icons_bundle.py`: иконки из Python-контекста,
      Jinja-выражений и `nav_link` есть в наборе
- [x] 3.3 `tests/test_icons_bundle.py`: файл на диске совпадает с результатом
      сборки (забытая пересборка ловится тестом)
- [x] 3.4 `tests/test_icons_bundle.py`: вес набора ограничен (96 КБ и четверть
      полного бандла)
- [x] 3.5 `tests/test_icons_bundle.py`: страница подключает набор, полного
      бандла нет в `app/static/`
- [x] 3.6 `tests/test_icons_bundle.py`: имена с цифрами (`trash-2`, `undo-2`)
      присутствуют в наборе

## 4. Документация

- [x] 4.1 `AGENTS.md`: правило про иконки (набор, пересборка, тест свежести) и
      команда в разделе «Команды»
- [x] 4.2 `README.md`: иконки — набор используемых, ~23 КБ
- [x] 4.3 Спека `ui-icons`: набор, контракт Lucide, полнота, офлайновая сборка

## 5. Проверка

- [x] 5.1 `uv run ruff check scripts/build_icons.py tests/test_icons_bundle.py`
- [x] 5.2 Полный прогон `uv run pytest -n auto` — 1706 passed
- [x] 5.3 Браузер 1440×900: 16/16 проверок — сайдбар (13 иконок), финансы
      (иконки из Python: `arrow-down-left`, `undo-2`, `arrow-up-right`), модалка
      после htmx-свопа, клонированная строка контакта, тёмная тема
      (`stroke=currentColor`), `icons.js` 23.6 КБ в сети, ни одного
      предупреждения о неизвестной иконке и ни одной JS-ошибки

Найдено и исправлено при проверке:

- рантайм искал иконку по PascalCase, а набор собран с ключами kebab-case —
  исправлено на прямой поиск по `data-lucide`;
- обратное преобразование Pascal → kebab теряло имена с цифрами
  (`trash-2`, `undo-2`) — заменено на прямой `pascal_name`;
- `*/` внутри комментария (`aria-*/role`) закрывал блок раньше времени и ломал
  синтаксис файла — комментарий переписан.
