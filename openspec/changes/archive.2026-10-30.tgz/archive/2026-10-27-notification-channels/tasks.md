# Tasks

## 1. Приёмная сторона ботов

- [x] 1.1 `app/messenger/services/errors.py`: исключение `BotApiError` (отдельно от `SendError` — это чтение, а не доставка).
- [x] 1.2 `app/messenger/services/telegram_bot_api.py`: `bot_username` (getMe) и `pending_updates` (getUpdates без offset); ошибки API/сети — `BotApiError`.
- [x] 1.3 `app/messenger/services/max_bot_api.py`: `bot_nickname` (GET /me) и `fetch_updates` (GET /updates, `timeout=0`, маркер); токен сырой строкой в `Authorization` — контракт `max_sender`.

## 2. Сервис привязки

- [x] 2.1 `app/messenger/services/messengers.py`: шаблоны диплинков `MESSENGER_LINK_TEMPLATES`, иконки карточек `MESSENGER_ICONS`.
- [x] 2.2 `app/messenger/services/binding.py`: ключи параметров (`bind_code_key`, `bind_link_key`, `chat_id_key`, `chat_label_key`, `marker_key`).
- [x] 2.3 `start_binding`: проверки (поддерживается, токен есть), ник бота из сети, одноразовый код + ссылка в параметры.
- [x] 2.4 `confirm_binding`: Telegram — точный `/start <код>`; MAX — плоский апдейт `bot_started` с payload на верхнем уровне, маркер от снапшота головы потока, потребление только просмотренного; успех — chat_id и подпись сохранены, код и ссылка удалены.
- [x] 2.5 `unbind_channel` и `channels_block_context` (карточка на каждый `SUPPORTED`, сетенезависимый рендер).

## 3. Вкладка «Уведомления»

- [x] 3.1 `app/tutor/views/profile_channels.py`: GET фрагмента (опрос/проверка), POST `connect`, POST `unlink`; htmx — фрагмент, без JS — 303; неизвестный мессенджер — 404.
- [x] 3.2 `app/tutor/services/profile_page.py` (`channels_block` в контексте) и `app/tutor/views/profile.py` (`?bind_error=1` — общий hint без JS).
- [x] 3.3 Шаблон `tutor/_channels_block.html` (три состояния карточки, автоопрос при незавершённой привязке), включение в `_tab_notifications.html`.
- [x] 3.4 CSS: `.channels-list`, `.channel-card` (+ модификаторы и элементы) в `app/static/styles.css`.

## 4. Тесты и документация

- [x] 4.1 `tests/test_notification_channels.py`: доступ, блок на вкладке, подключение Telegram/MAX с подменой urlopen (успех/ошибка API/сеть), подтверждение по апдейтам, отвязка, 404, редиректы без JS, изоляция по репетитору.
- [x] 4.2 README: краткое описание привязки каналов.
- [x] 4.3 `uv run pytest -n auto` зелёный; обновить затронутые разделы README.

## 5. TLS к Bot API

- [x] 5.1 `app/config.py`: настройка `messenger_tls_verify` (по умолчанию true).
- [x] 5.2 `app/messenger/services/tls_context.py`: `api_ssl_context()`; подключён во все вызовы Bot API (клиенты привязки и отправители).
- [x] 5.3 Тесты: проверка включена по умолчанию, флаг отключает; README — когда ставить флаг.

## 6. Приветственное сообщение

- [x] 6.1 `app/messenger/services/welcome.py`: текст и `send_welcome` через общий `send_message`.
- [x] 6.2 `confirm_binding`: после сохранения чата шлёт приветствие; сбой не отменяет привязку, ошибка — в блоке.
- [x] 6.3 Тесты: приветствие Telegram (chat_id + текст) и MAX (`POST /messages?chat_id=`), сбой приветствия не ломает привязку.
