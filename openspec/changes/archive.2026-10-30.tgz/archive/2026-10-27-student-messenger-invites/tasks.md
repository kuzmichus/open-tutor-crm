# Tasks

## 1. Модель и миграция

- [x] 1.1 `app/messenger/models/student_invite.py`: `StudentMessengerInvite` (таблица `student_messenger_invites`, UNIQUE(student_id, messenger), CHECK по `MESSENGERS`, CASCADE по ученику и репетитору); регистрация в `app/models.py`.
- [x] 1.2 Миграция `uv run alembic revision --autogenerate -m "add student messenger invites"` и `alembic upgrade head`.

## 2. Общая приёмная сторона

- [x] 2.1 `binding.py`: `confirm_binding` читает апдейты один раз и матчит код канала и коды приглашений; попадания пакетные, маркер MAX — по прежнему правилу плюс при попадании.
- [x] 2.2 Публичные хелперы: `bot_name`, `ensure_max_marker` (снапшот только при отсутствии маркера), `CODE_BYTES`; `start_binding` переходит на `ensure_max_marker`.

## 3. Сервис приглашений

- [x] 3.1 `app/messenger/services/student_invites.py`: `start_invite` (проверки, ник бота из сети, код+ссылка в строку, для MAX — гарантия маркера), `unbind_student`, `invites_context` (сетенезависимый рендер).

## 4. Блок в карточке ученика

- [x] 4.1 `app/student/views/messengers.py`: GET фрагмента (опрос/проверка), POST `invite`, POST `unlink`; htmx — фрагмент, без JS — 303; чужой ученик — 404; неизвестный мессенджер — 404. Роутер в `app/student/views/__init__.py`.
- [x] 4.2 `form_context` кладёт `invites_block` (только для существующего ученика); шаблон `student/_invites_block.html` (три состояния карточки, автополлинг, кнопки без вложенных форм — `hx-post` + `formaction`), включение в `_form.html` на вкладке «Настройки».
- [x] 4.3 Alpine-фабрика `studentInvites` в `app/static/students.js`: автокопирование по `data-autocopy`, кнопка «Скопировать ссылку», подсказка при недоступном буфере.
- [x] 4.4 CSS: `.invite-list`, `.invite-link`, `.invite-actions`, `.invite-status` в `app/static/styles.css` (карточки — переиспользование `.channel-card*`).

## 5. Тесты и документация

- [x] 5.1 `tests/test_student_messenger_invites.py`: доступ и изоляция, блок на вкладке, генерация ссылки Telegram/MAX с подменой urlopen, ошибка API/сети, подтверждение по апдейтам (Telegram и MAX), старты ученика и репетитора в одной пачке, повторное приглашение, отвязка, 404, редиректы без JS, у нового ученика блока нет.
- [x] 5.2 README: приглашение ученика из карточки.
- [x] 5.3 `uv run pytest -n auto` зелёный, включая существующие `test_notification_channels.py`.
